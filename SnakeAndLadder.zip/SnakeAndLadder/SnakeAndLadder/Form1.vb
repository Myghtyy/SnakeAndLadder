﻿Public Class Form1
    Inherits System.Windows.Forms.Form
    Dim random As Random
    Dim curr_turn As String = "Player 2"
    Dim count As Integer
    Dim num As Integer
    Private Sub xyz()
        If curr_turn = "Player 2" Then
            curr_turn = "Player 1"
        ElseIf curr_turn = "Player 1" And num = 6 Then
            curr_turn = "Player 1"
            Label1.Text = curr_turn
        ElseIf curr_turn = "Player 2" And num = 6 Then
            curr_turn = "Player 2"
            Label1.Text = curr_turn

        Else
            curr_turn = "Player 2"
        End If
        Label1.Text = curr_turn
    End Sub
    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnrotate.Click
        Timer1.Start()
        num = Math.Ceiling(Rnd() * 6)
        xyz()
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Label1.Text = "Current Turn"
    End Sub


    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        random = New Random
        ProgressBar1.Increment(10)
        If ProgressBar1.Value = 100 Then
            Timer1.Stop()
            ProgressBar1.Value = 0
        Else
            num = random.Next(1, 7)
            If num = 1 Then
                pctDice.ImageLocation = "C:\Users\ASUS\Pictures\Dice\1.png"
            ElseIf num = 2 Then
                pctDice.ImageLocation = "C:\Users\ASUS\Pictures\Dice\2.png"
            ElseIf num = 3 Then
                pctDice.ImageLocation = "C:\Users\ASUS\Pictures\Dice\3.png"
            ElseIf num = 4 Then
                pctDice.ImageLocation = "C:\Users\ASUS\Pictures\Dice\4.png"
            ElseIf num = 5 Then
                pctDice.ImageLocation = "C:\Users\ASUS\Pictures\Dice\5.png"
            ElseIf num = 6 Then
                pctDice.ImageLocation = "C:\Users\ASUS\Pictures\Dice\6.png"
            End If
        End If
    End Sub
    Private Sub abc()
        If curr_turn = "Player 1" And num = 6 Then
            curr_turn = "Player 1"
        ElseIf curr_turn = "Player 2" And num = 6 Then
            curr_turn = "Player 2"
        End If
    End Sub
End Class

