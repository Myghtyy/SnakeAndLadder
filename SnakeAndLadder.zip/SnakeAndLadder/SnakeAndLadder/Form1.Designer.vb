﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lblblue = New System.Windows.Forms.Label()
        Me.lblred = New System.Windows.Forms.Label()
        Me.lblplayer2 = New System.Windows.Forms.Label()
        Me.pctDice = New System.Windows.Forms.PictureBox()
        Me.btnrotate = New System.Windows.Forms.Button()
        Me.lbl17 = New System.Windows.Forms.Label()
        Me.lblplayer1 = New System.Windows.Forms.Label()
        Me.lbl100 = New System.Windows.Forms.Label()
        Me.lbl99 = New System.Windows.Forms.Label()
        Me.lbl98 = New System.Windows.Forms.Label()
        Me.lbl97 = New System.Windows.Forms.Label()
        Me.lbl96 = New System.Windows.Forms.Label()
        Me.lbl95 = New System.Windows.Forms.Label()
        Me.lbl94 = New System.Windows.Forms.Label()
        Me.lbl93 = New System.Windows.Forms.Label()
        Me.lbl92 = New System.Windows.Forms.Label()
        Me.lbl91 = New System.Windows.Forms.Label()
        Me.lbl90 = New System.Windows.Forms.Label()
        Me.lbl89 = New System.Windows.Forms.Label()
        Me.lbl88 = New System.Windows.Forms.Label()
        Me.lbl87 = New System.Windows.Forms.Label()
        Me.lbl86 = New System.Windows.Forms.Label()
        Me.lbl85 = New System.Windows.Forms.Label()
        Me.lbl84 = New System.Windows.Forms.Label()
        Me.lbl83 = New System.Windows.Forms.Label()
        Me.lbl82 = New System.Windows.Forms.Label()
        Me.lbl81 = New System.Windows.Forms.Label()
        Me.lbl80 = New System.Windows.Forms.Label()
        Me.lbl79 = New System.Windows.Forms.Label()
        Me.lbl78 = New System.Windows.Forms.Label()
        Me.lbl77 = New System.Windows.Forms.Label()
        Me.lbl76 = New System.Windows.Forms.Label()
        Me.lbl75 = New System.Windows.Forms.Label()
        Me.lbl74 = New System.Windows.Forms.Label()
        Me.lbl73 = New System.Windows.Forms.Label()
        Me.lbl72 = New System.Windows.Forms.Label()
        Me.lbl71 = New System.Windows.Forms.Label()
        Me.lbl70 = New System.Windows.Forms.Label()
        Me.lbl69 = New System.Windows.Forms.Label()
        Me.lbl68 = New System.Windows.Forms.Label()
        Me.lbl67 = New System.Windows.Forms.Label()
        Me.lbl66 = New System.Windows.Forms.Label()
        Me.lbl65 = New System.Windows.Forms.Label()
        Me.lbl64 = New System.Windows.Forms.Label()
        Me.lbl63 = New System.Windows.Forms.Label()
        Me.lbl62 = New System.Windows.Forms.Label()
        Me.lbl61 = New System.Windows.Forms.Label()
        Me.lbl60 = New System.Windows.Forms.Label()
        Me.lbl59 = New System.Windows.Forms.Label()
        Me.lbl58 = New System.Windows.Forms.Label()
        Me.lbl57 = New System.Windows.Forms.Label()
        Me.lbl56 = New System.Windows.Forms.Label()
        Me.lbl55 = New System.Windows.Forms.Label()
        Me.lbl54 = New System.Windows.Forms.Label()
        Me.lbl53 = New System.Windows.Forms.Label()
        Me.lbl52 = New System.Windows.Forms.Label()
        Me.lbl51 = New System.Windows.Forms.Label()
        Me.lbl50 = New System.Windows.Forms.Label()
        Me.lbl49 = New System.Windows.Forms.Label()
        Me.lbl48 = New System.Windows.Forms.Label()
        Me.lbl47 = New System.Windows.Forms.Label()
        Me.lbl46 = New System.Windows.Forms.Label()
        Me.lbl45 = New System.Windows.Forms.Label()
        Me.lbl44 = New System.Windows.Forms.Label()
        Me.lbl43 = New System.Windows.Forms.Label()
        Me.lbl42 = New System.Windows.Forms.Label()
        Me.lbl41 = New System.Windows.Forms.Label()
        Me.lbl40 = New System.Windows.Forms.Label()
        Me.lbl39 = New System.Windows.Forms.Label()
        Me.lbl38 = New System.Windows.Forms.Label()
        Me.lbl37 = New System.Windows.Forms.Label()
        Me.lbl36 = New System.Windows.Forms.Label()
        Me.lbl35 = New System.Windows.Forms.Label()
        Me.lbl34 = New System.Windows.Forms.Label()
        Me.lbl33 = New System.Windows.Forms.Label()
        Me.lbl32 = New System.Windows.Forms.Label()
        Me.lbl31 = New System.Windows.Forms.Label()
        Me.lbl30 = New System.Windows.Forms.Label()
        Me.lbl29 = New System.Windows.Forms.Label()
        Me.lbl28 = New System.Windows.Forms.Label()
        Me.lbl27 = New System.Windows.Forms.Label()
        Me.lbl26 = New System.Windows.Forms.Label()
        Me.lbl25 = New System.Windows.Forms.Label()
        Me.lbl24 = New System.Windows.Forms.Label()
        Me.lbl23 = New System.Windows.Forms.Label()
        Me.lbl22 = New System.Windows.Forms.Label()
        Me.lbl21 = New System.Windows.Forms.Label()
        Me.lbl20 = New System.Windows.Forms.Label()
        Me.lbl19 = New System.Windows.Forms.Label()
        Me.lbl18 = New System.Windows.Forms.Label()
        Me.lbl16 = New System.Windows.Forms.Label()
        Me.lbl15 = New System.Windows.Forms.Label()
        Me.lbl14 = New System.Windows.Forms.Label()
        Me.lbl13 = New System.Windows.Forms.Label()
        Me.lbl12 = New System.Windows.Forms.Label()
        Me.lbl11 = New System.Windows.Forms.Label()
        Me.lbl10 = New System.Windows.Forms.Label()
        Me.lbl9 = New System.Windows.Forms.Label()
        Me.lbl8 = New System.Windows.Forms.Label()
        Me.lbl7 = New System.Windows.Forms.Label()
        Me.lbl6 = New System.Windows.Forms.Label()
        Me.lbl5 = New System.Windows.Forms.Label()
        Me.lbl4 = New System.Windows.Forms.Label()
        Me.lbl3 = New System.Windows.Forms.Label()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pctDice, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(0, 4)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(932, 788)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'lblblue
        '
        Me.lblblue.AutoSize = True
        Me.lblblue.BackColor = System.Drawing.Color.Blue
        Me.lblblue.ForeColor = System.Drawing.Color.Crimson
        Me.lblblue.Location = New System.Drawing.Point(1076, 137)
        Me.lblblue.Name = "lblblue"
        Me.lblblue.Size = New System.Drawing.Size(20, 17)
        Me.lblblue.TabIndex = 107
        Me.lblblue.Text = "   "
        '
        'lblred
        '
        Me.lblred.AutoSize = True
        Me.lblred.BackColor = System.Drawing.Color.Red
        Me.lblred.Location = New System.Drawing.Point(1076, 102)
        Me.lblred.Name = "lblred"
        Me.lblred.Size = New System.Drawing.Size(20, 17)
        Me.lblred.TabIndex = 106
        Me.lblred.Text = "   "
        '
        'lblplayer2
        '
        Me.lblplayer2.AutoSize = True
        Me.lblplayer2.BackColor = System.Drawing.Color.Transparent
        Me.lblplayer2.Location = New System.Drawing.Point(998, 137)
        Me.lblplayer2.Name = "lblplayer2"
        Me.lblplayer2.Size = New System.Drawing.Size(72, 17)
        Me.lblplayer2.TabIndex = 105
        Me.lblplayer2.Text = "Player 2 : "
        '
        'pctDice
        '
        Me.pctDice.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.pctDice.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pctDice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pctDice.Enabled = False
        Me.pctDice.Location = New System.Drawing.Point(967, 199)
        Me.pctDice.Name = "pctDice"
        Me.pctDice.Size = New System.Drawing.Size(208, 141)
        Me.pctDice.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pctDice.TabIndex = 104
        Me.pctDice.TabStop = False
        Me.pctDice.WaitOnLoad = True
        '
        'btnrotate
        '
        Me.btnrotate.AccessibleRole = System.Windows.Forms.AccessibleRole.TitleBar
        Me.btnrotate.AllowDrop = True
        Me.btnrotate.AutoEllipsis = True
        Me.btnrotate.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnrotate.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnrotate.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.btnrotate.FlatAppearance.BorderColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnrotate.FlatAppearance.BorderSize = 3
        Me.btnrotate.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnrotate.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrotate.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnrotate.Location = New System.Drawing.Point(1017, 362)
        Me.btnrotate.Name = "btnrotate"
        Me.btnrotate.Size = New System.Drawing.Size(108, 51)
        Me.btnrotate.TabIndex = 103
        Me.btnrotate.Text = "Rotate"
        Me.btnrotate.UseVisualStyleBackColor = False
        '
        'lbl17
        '
        Me.lbl17.AutoSize = True
        Me.lbl17.BackColor = System.Drawing.Color.LightGreen
        Me.lbl17.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.lbl17.ForeColor = System.Drawing.Color.LightGreen
        Me.lbl17.Location = New System.Drawing.Point(618, 675)
        Me.lbl17.Name = "lbl17"
        Me.lbl17.Size = New System.Drawing.Size(20, 17)
        Me.lbl17.TabIndex = 17
        Me.lbl17.Text = "   "
        '
        'lblplayer1
        '
        Me.lblplayer1.AutoSize = True
        Me.lblplayer1.BackColor = System.Drawing.Color.Transparent
        Me.lblplayer1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.lblplayer1.Location = New System.Drawing.Point(998, 102)
        Me.lblplayer1.Name = "lblplayer1"
        Me.lblplayer1.Size = New System.Drawing.Size(72, 17)
        Me.lblplayer1.TabIndex = 101
        Me.lblplayer1.Text = "Player 1 : "
        '
        'lbl100
        '
        Me.lbl100.AutoSize = True
        Me.lbl100.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl100.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl100.Location = New System.Drawing.Point(868, 55)
        Me.lbl100.Name = "lbl100"
        Me.lbl100.Size = New System.Drawing.Size(20, 17)
        Me.lbl100.TabIndex = 100
        Me.lbl100.Text = "   "
        '
        'lbl99
        '
        Me.lbl99.AutoSize = True
        Me.lbl99.BackColor = System.Drawing.Color.Yellow
        Me.lbl99.Location = New System.Drawing.Point(767, 31)
        Me.lbl99.Name = "lbl99"
        Me.lbl99.Size = New System.Drawing.Size(20, 17)
        Me.lbl99.TabIndex = 99
        Me.lbl99.Text = "   "
        '
        'lbl98
        '
        Me.lbl98.AutoSize = True
        Me.lbl98.BackColor = System.Drawing.Color.LightGreen
        Me.lbl98.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.lbl98.ForeColor = System.Drawing.Color.LightGreen
        Me.lbl98.Location = New System.Drawing.Point(694, 39)
        Me.lbl98.Name = "lbl98"
        Me.lbl98.Size = New System.Drawing.Size(20, 17)
        Me.lbl98.TabIndex = 98
        Me.lbl98.Text = "   "
        '
        'lbl97
        '
        Me.lbl97.AutoSize = True
        Me.lbl97.BackColor = System.Drawing.Color.Transparent
        Me.lbl97.Location = New System.Drawing.Point(577, 39)
        Me.lbl97.Name = "lbl97"
        Me.lbl97.Size = New System.Drawing.Size(20, 17)
        Me.lbl97.TabIndex = 97
        Me.lbl97.Text = "   "
        '
        'lbl96
        '
        Me.lbl96.AutoSize = True
        Me.lbl96.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.lbl96.Location = New System.Drawing.Point(486, 31)
        Me.lbl96.Name = "lbl96"
        Me.lbl96.Size = New System.Drawing.Size(20, 17)
        Me.lbl96.TabIndex = 96
        Me.lbl96.Text = "   "
        '
        'lbl95
        '
        Me.lbl95.AutoSize = True
        Me.lbl95.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl95.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl95.Location = New System.Drawing.Point(416, 39)
        Me.lbl95.Name = "lbl95"
        Me.lbl95.Size = New System.Drawing.Size(20, 17)
        Me.lbl95.TabIndex = 95
        Me.lbl95.Text = "   "
        '
        'lbl94
        '
        Me.lbl94.AutoSize = True
        Me.lbl94.BackColor = System.Drawing.Color.Yellow
        Me.lbl94.Location = New System.Drawing.Point(305, 31)
        Me.lbl94.Name = "lbl94"
        Me.lbl94.Size = New System.Drawing.Size(20, 17)
        Me.lbl94.TabIndex = 94
        Me.lbl94.Text = "   "
        '
        'lbl93
        '
        Me.lbl93.AutoSize = True
        Me.lbl93.BackColor = System.Drawing.Color.LightGreen
        Me.lbl93.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.lbl93.ForeColor = System.Drawing.Color.LightGreen
        Me.lbl93.Location = New System.Drawing.Point(200, 31)
        Me.lbl93.Name = "lbl93"
        Me.lbl93.Size = New System.Drawing.Size(20, 17)
        Me.lbl93.TabIndex = 93
        Me.lbl93.Text = "   "
        '
        'lbl92
        '
        Me.lbl92.AutoSize = True
        Me.lbl92.BackColor = System.Drawing.Color.Transparent
        Me.lbl92.Location = New System.Drawing.Point(115, 31)
        Me.lbl92.Name = "lbl92"
        Me.lbl92.Size = New System.Drawing.Size(20, 17)
        Me.lbl92.TabIndex = 92
        Me.lbl92.Text = "   "
        '
        'lbl91
        '
        Me.lbl91.AutoSize = True
        Me.lbl91.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.lbl91.Location = New System.Drawing.Point(14, 8)
        Me.lbl91.Name = "lbl91"
        Me.lbl91.Size = New System.Drawing.Size(20, 17)
        Me.lbl91.TabIndex = 91
        Me.lbl91.Text = "   "
        '
        'lbl90
        '
        Me.lbl90.AutoSize = True
        Me.lbl90.BackColor = System.Drawing.Color.Transparent
        Me.lbl90.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.lbl90.Location = New System.Drawing.Point(865, 115)
        Me.lbl90.Name = "lbl90"
        Me.lbl90.Size = New System.Drawing.Size(20, 17)
        Me.lbl90.TabIndex = 90
        Me.lbl90.Text = "   "
        '
        'lbl89
        '
        Me.lbl89.AutoSize = True
        Me.lbl89.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.lbl89.Location = New System.Drawing.Point(764, 102)
        Me.lbl89.Name = "lbl89"
        Me.lbl89.Size = New System.Drawing.Size(20, 17)
        Me.lbl89.TabIndex = 89
        Me.lbl89.Text = "   "
        '
        'lbl88
        '
        Me.lbl88.AutoSize = True
        Me.lbl88.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl88.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl88.Location = New System.Drawing.Point(694, 127)
        Me.lbl88.Name = "lbl88"
        Me.lbl88.Size = New System.Drawing.Size(20, 17)
        Me.lbl88.TabIndex = 88
        Me.lbl88.Text = "   "
        '
        'lbl87
        '
        Me.lbl87.AutoSize = True
        Me.lbl87.BackColor = System.Drawing.Color.Yellow
        Me.lbl87.Location = New System.Drawing.Point(577, 102)
        Me.lbl87.Name = "lbl87"
        Me.lbl87.Size = New System.Drawing.Size(20, 17)
        Me.lbl87.TabIndex = 87
        Me.lbl87.Text = "   "
        '
        'lbl86
        '
        Me.lbl86.AutoSize = True
        Me.lbl86.BackColor = System.Drawing.Color.LightGreen
        Me.lbl86.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.lbl86.ForeColor = System.Drawing.Color.LightGreen
        Me.lbl86.Location = New System.Drawing.Point(483, 102)
        Me.lbl86.Name = "lbl86"
        Me.lbl86.Size = New System.Drawing.Size(20, 17)
        Me.lbl86.TabIndex = 86
        Me.lbl86.Text = "   "
        '
        'lbl85
        '
        Me.lbl85.AutoSize = True
        Me.lbl85.BackColor = System.Drawing.Color.Transparent
        Me.lbl85.Location = New System.Drawing.Point(425, 127)
        Me.lbl85.Name = "lbl85"
        Me.lbl85.Size = New System.Drawing.Size(20, 17)
        Me.lbl85.TabIndex = 85
        Me.lbl85.Text = "   "
        '
        'lbl84
        '
        Me.lbl84.AutoSize = True
        Me.lbl84.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.lbl84.Location = New System.Drawing.Point(293, 102)
        Me.lbl84.Name = "lbl84"
        Me.lbl84.Size = New System.Drawing.Size(20, 17)
        Me.lbl84.TabIndex = 84
        Me.lbl84.Text = "   "
        '
        'lbl83
        '
        Me.lbl83.AutoSize = True
        Me.lbl83.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl83.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl83.Location = New System.Drawing.Point(200, 115)
        Me.lbl83.Name = "lbl83"
        Me.lbl83.Size = New System.Drawing.Size(20, 17)
        Me.lbl83.TabIndex = 83
        Me.lbl83.Text = "   "
        '
        'lbl82
        '
        Me.lbl82.AutoSize = True
        Me.lbl82.BackColor = System.Drawing.Color.Yellow
        Me.lbl82.Location = New System.Drawing.Point(128, 115)
        Me.lbl82.Name = "lbl82"
        Me.lbl82.Size = New System.Drawing.Size(20, 17)
        Me.lbl82.TabIndex = 82
        Me.lbl82.Text = "   "
        '
        'lbl81
        '
        Me.lbl81.AutoSize = True
        Me.lbl81.BackColor = System.Drawing.Color.LightGreen
        Me.lbl81.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.lbl81.ForeColor = System.Drawing.Color.LightGreen
        Me.lbl81.Location = New System.Drawing.Point(14, 115)
        Me.lbl81.Name = "lbl81"
        Me.lbl81.Size = New System.Drawing.Size(20, 17)
        Me.lbl81.TabIndex = 81
        Me.lbl81.Text = "   "
        '
        'lbl80
        '
        Me.lbl80.AutoSize = True
        Me.lbl80.BackColor = System.Drawing.Color.Yellow
        Me.lbl80.Location = New System.Drawing.Point(865, 168)
        Me.lbl80.Name = "lbl80"
        Me.lbl80.Size = New System.Drawing.Size(20, 17)
        Me.lbl80.TabIndex = 80
        Me.lbl80.Text = "   "
        '
        'lbl79
        '
        Me.lbl79.AutoSize = True
        Me.lbl79.BackColor = System.Drawing.Color.LightGreen
        Me.lbl79.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.lbl79.ForeColor = System.Drawing.Color.LightGreen
        Me.lbl79.Location = New System.Drawing.Point(806, 190)
        Me.lbl79.Name = "lbl79"
        Me.lbl79.Size = New System.Drawing.Size(20, 17)
        Me.lbl79.TabIndex = 79
        Me.lbl79.Text = "   "
        '
        'lbl78
        '
        Me.lbl78.AutoSize = True
        Me.lbl78.BackColor = System.Drawing.Color.Transparent
        Me.lbl78.Location = New System.Drawing.Point(694, 190)
        Me.lbl78.Name = "lbl78"
        Me.lbl78.Size = New System.Drawing.Size(20, 17)
        Me.lbl78.TabIndex = 78
        Me.lbl78.Text = "   "
        '
        'lbl77
        '
        Me.lbl77.AutoSize = True
        Me.lbl77.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.lbl77.Location = New System.Drawing.Point(577, 199)
        Me.lbl77.Name = "lbl77"
        Me.lbl77.Size = New System.Drawing.Size(20, 17)
        Me.lbl77.TabIndex = 77
        Me.lbl77.Text = "   "
        '
        'lbl76
        '
        Me.lbl76.AutoSize = True
        Me.lbl76.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl76.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl76.Location = New System.Drawing.Point(486, 199)
        Me.lbl76.Name = "lbl76"
        Me.lbl76.Size = New System.Drawing.Size(20, 17)
        Me.lbl76.TabIndex = 76
        Me.lbl76.Text = "   "
        '
        'lbl75
        '
        Me.lbl75.AutoSize = True
        Me.lbl75.BackColor = System.Drawing.Color.Yellow
        Me.lbl75.Location = New System.Drawing.Point(401, 199)
        Me.lbl75.Name = "lbl75"
        Me.lbl75.Size = New System.Drawing.Size(20, 17)
        Me.lbl75.TabIndex = 75
        Me.lbl75.Text = "   "
        '
        'lbl74
        '
        Me.lbl74.AutoSize = True
        Me.lbl74.BackColor = System.Drawing.Color.LightGreen
        Me.lbl74.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.lbl74.ForeColor = System.Drawing.Color.LightGreen
        Me.lbl74.Location = New System.Drawing.Point(293, 190)
        Me.lbl74.Name = "lbl74"
        Me.lbl74.Size = New System.Drawing.Size(20, 17)
        Me.lbl74.TabIndex = 74
        Me.lbl74.Text = "   "
        '
        'lbl73
        '
        Me.lbl73.AutoSize = True
        Me.lbl73.BackColor = System.Drawing.Color.Transparent
        Me.lbl73.Location = New System.Drawing.Point(221, 199)
        Me.lbl73.Name = "lbl73"
        Me.lbl73.Size = New System.Drawing.Size(20, 17)
        Me.lbl73.TabIndex = 73
        Me.lbl73.Text = "   "
        '
        'lbl72
        '
        Me.lbl72.AutoSize = True
        Me.lbl72.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.lbl72.Location = New System.Drawing.Point(152, 199)
        Me.lbl72.Name = "lbl72"
        Me.lbl72.Size = New System.Drawing.Size(20, 17)
        Me.lbl72.TabIndex = 72
        Me.lbl72.Text = "   "
        '
        'lbl71
        '
        Me.lbl71.AutoSize = True
        Me.lbl71.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl71.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl71.Location = New System.Drawing.Point(14, 181)
        Me.lbl71.Name = "lbl71"
        Me.lbl71.Size = New System.Drawing.Size(20, 17)
        Me.lbl71.TabIndex = 71
        Me.lbl71.Text = "   "
        '
        'lbl70
        '
        Me.lbl70.AutoSize = True
        Me.lbl70.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.lbl70.Location = New System.Drawing.Point(868, 269)
        Me.lbl70.Name = "lbl70"
        Me.lbl70.Size = New System.Drawing.Size(20, 17)
        Me.lbl70.TabIndex = 70
        Me.lbl70.Text = "   "
        '
        'lbl69
        '
        Me.lbl69.AutoSize = True
        Me.lbl69.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl69.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl69.Location = New System.Drawing.Point(764, 269)
        Me.lbl69.Name = "lbl69"
        Me.lbl69.Size = New System.Drawing.Size(20, 17)
        Me.lbl69.TabIndex = 69
        Me.lbl69.Text = "   "
        '
        'lbl68
        '
        Me.lbl68.AutoSize = True
        Me.lbl68.BackColor = System.Drawing.Color.Yellow
        Me.lbl68.Location = New System.Drawing.Point(694, 287)
        Me.lbl68.Name = "lbl68"
        Me.lbl68.Size = New System.Drawing.Size(20, 17)
        Me.lbl68.TabIndex = 68
        Me.lbl68.Text = "   "
        '
        'lbl67
        '
        Me.lbl67.AutoSize = True
        Me.lbl67.BackColor = System.Drawing.Color.LightGreen
        Me.lbl67.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.lbl67.ForeColor = System.Drawing.Color.LightGreen
        Me.lbl67.Location = New System.Drawing.Point(618, 287)
        Me.lbl67.Name = "lbl67"
        Me.lbl67.Size = New System.Drawing.Size(20, 17)
        Me.lbl67.TabIndex = 67
        Me.lbl67.Text = "   "
        '
        'lbl66
        '
        Me.lbl66.AutoSize = True
        Me.lbl66.BackColor = System.Drawing.Color.Transparent
        Me.lbl66.Location = New System.Drawing.Point(508, 287)
        Me.lbl66.Name = "lbl66"
        Me.lbl66.Size = New System.Drawing.Size(20, 17)
        Me.lbl66.TabIndex = 66
        Me.lbl66.Text = "   "
        '
        'lbl65
        '
        Me.lbl65.AutoSize = True
        Me.lbl65.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.lbl65.Location = New System.Drawing.Point(439, 287)
        Me.lbl65.Name = "lbl65"
        Me.lbl65.Size = New System.Drawing.Size(20, 17)
        Me.lbl65.TabIndex = 65
        Me.lbl65.Text = "   "
        '
        'lbl64
        '
        Me.lbl64.AutoSize = True
        Me.lbl64.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl64.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl64.Location = New System.Drawing.Point(344, 287)
        Me.lbl64.Name = "lbl64"
        Me.lbl64.Size = New System.Drawing.Size(20, 17)
        Me.lbl64.TabIndex = 64
        Me.lbl64.Text = "   "
        '
        'lbl63
        '
        Me.lbl63.AutoSize = True
        Me.lbl63.BackColor = System.Drawing.Color.Yellow
        Me.lbl63.Location = New System.Drawing.Point(221, 287)
        Me.lbl63.Name = "lbl63"
        Me.lbl63.Size = New System.Drawing.Size(20, 17)
        Me.lbl63.TabIndex = 63
        Me.lbl63.Text = "   "
        '
        'lbl62
        '
        Me.lbl62.AutoSize = True
        Me.lbl62.BackColor = System.Drawing.Color.LightGreen
        Me.lbl62.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.lbl62.ForeColor = System.Drawing.Color.LightGreen
        Me.lbl62.Location = New System.Drawing.Point(115, 251)
        Me.lbl62.Name = "lbl62"
        Me.lbl62.Size = New System.Drawing.Size(20, 17)
        Me.lbl62.TabIndex = 62
        Me.lbl62.Text = "   "
        '
        'lbl61
        '
        Me.lbl61.AutoSize = True
        Me.lbl61.BackColor = System.Drawing.Color.Transparent
        Me.lbl61.Location = New System.Drawing.Point(14, 260)
        Me.lbl61.Name = "lbl61"
        Me.lbl61.Size = New System.Drawing.Size(20, 17)
        Me.lbl61.TabIndex = 61
        Me.lbl61.Text = "   "
        '
        'lbl60
        '
        Me.lbl60.AutoSize = True
        Me.lbl60.BackColor = System.Drawing.Color.LightGreen
        Me.lbl60.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.lbl60.ForeColor = System.Drawing.Color.LightGreen
        Me.lbl60.Location = New System.Drawing.Point(868, 373)
        Me.lbl60.Name = "lbl60"
        Me.lbl60.Size = New System.Drawing.Size(20, 17)
        Me.lbl60.TabIndex = 60
        Me.lbl60.Text = "   "
        '
        'lbl59
        '
        Me.lbl59.AutoSize = True
        Me.lbl59.BackColor = System.Drawing.Color.Transparent
        Me.lbl59.Location = New System.Drawing.Point(764, 351)
        Me.lbl59.Name = "lbl59"
        Me.lbl59.Size = New System.Drawing.Size(20, 17)
        Me.lbl59.TabIndex = 59
        Me.lbl59.Text = "   "
        '
        'lbl58
        '
        Me.lbl58.AutoSize = True
        Me.lbl58.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.lbl58.Location = New System.Drawing.Point(683, 351)
        Me.lbl58.Name = "lbl58"
        Me.lbl58.Size = New System.Drawing.Size(20, 17)
        Me.lbl58.TabIndex = 58
        Me.lbl58.Text = "   "
        '
        'lbl57
        '
        Me.lbl57.AutoSize = True
        Me.lbl57.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl57.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl57.Location = New System.Drawing.Point(629, 361)
        Me.lbl57.Name = "lbl57"
        Me.lbl57.Size = New System.Drawing.Size(20, 17)
        Me.lbl57.TabIndex = 57
        Me.lbl57.Text = "   "
        '
        'lbl56
        '
        Me.lbl56.AutoSize = True
        Me.lbl56.BackColor = System.Drawing.Color.Yellow
        Me.lbl56.Location = New System.Drawing.Point(486, 351)
        Me.lbl56.Name = "lbl56"
        Me.lbl56.Size = New System.Drawing.Size(20, 17)
        Me.lbl56.TabIndex = 56
        Me.lbl56.Text = "   "
        '
        'lbl55
        '
        Me.lbl55.AutoSize = True
        Me.lbl55.BackColor = System.Drawing.Color.LightGreen
        Me.lbl55.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.lbl55.ForeColor = System.Drawing.Color.LightGreen
        Me.lbl55.Location = New System.Drawing.Point(386, 333)
        Me.lbl55.Name = "lbl55"
        Me.lbl55.Size = New System.Drawing.Size(20, 17)
        Me.lbl55.TabIndex = 55
        Me.lbl55.Text = "   "
        '
        'lbl54
        '
        Me.lbl54.AutoSize = True
        Me.lbl54.BackColor = System.Drawing.Color.Transparent
        Me.lbl54.Location = New System.Drawing.Point(320, 361)
        Me.lbl54.Name = "lbl54"
        Me.lbl54.Size = New System.Drawing.Size(20, 17)
        Me.lbl54.TabIndex = 54
        Me.lbl54.Text = "   "
        '
        'lbl53
        '
        Me.lbl53.AutoSize = True
        Me.lbl53.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.lbl53.Location = New System.Drawing.Point(221, 361)
        Me.lbl53.Name = "lbl53"
        Me.lbl53.Size = New System.Drawing.Size(20, 17)
        Me.lbl53.TabIndex = 53
        Me.lbl53.Text = "   "
        '
        'lbl52
        '
        Me.lbl52.AutoSize = True
        Me.lbl52.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl52.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl52.Location = New System.Drawing.Point(128, 351)
        Me.lbl52.Name = "lbl52"
        Me.lbl52.Size = New System.Drawing.Size(20, 17)
        Me.lbl52.TabIndex = 52
        Me.lbl52.Text = "   "
        '
        'lbl51
        '
        Me.lbl51.AutoSize = True
        Me.lbl51.BackColor = System.Drawing.Color.Yellow
        Me.lbl51.Location = New System.Drawing.Point(52, 361)
        Me.lbl51.Name = "lbl51"
        Me.lbl51.Size = New System.Drawing.Size(20, 17)
        Me.lbl51.TabIndex = 51
        Me.lbl51.Text = "   "
        '
        'lbl50
        '
        Me.lbl50.AutoSize = True
        Me.lbl50.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl50.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl50.Location = New System.Drawing.Point(877, 429)
        Me.lbl50.Name = "lbl50"
        Me.lbl50.Size = New System.Drawing.Size(20, 17)
        Me.lbl50.TabIndex = 50
        Me.lbl50.Text = "   "
        '
        'lbl49
        '
        Me.lbl49.AutoSize = True
        Me.lbl49.BackColor = System.Drawing.Color.Yellow
        Me.lbl49.Location = New System.Drawing.Point(767, 435)
        Me.lbl49.Name = "lbl49"
        Me.lbl49.Size = New System.Drawing.Size(20, 17)
        Me.lbl49.TabIndex = 49
        Me.lbl49.Text = "   "
        '
        'lbl48
        '
        Me.lbl48.AutoSize = True
        Me.lbl48.BackColor = System.Drawing.Color.LightGreen
        Me.lbl48.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.lbl48.ForeColor = System.Drawing.Color.LightGreen
        Me.lbl48.Location = New System.Drawing.Point(668, 411)
        Me.lbl48.Name = "lbl48"
        Me.lbl48.Size = New System.Drawing.Size(20, 17)
        Me.lbl48.TabIndex = 48
        Me.lbl48.Text = "   "
        '
        'lbl47
        '
        Me.lbl47.AutoSize = True
        Me.lbl47.BackColor = System.Drawing.Color.Transparent
        Me.lbl47.Location = New System.Drawing.Point(577, 411)
        Me.lbl47.Name = "lbl47"
        Me.lbl47.Size = New System.Drawing.Size(20, 17)
        Me.lbl47.TabIndex = 47
        Me.lbl47.Text = "   "
        '
        'lbl46
        '
        Me.lbl46.AutoSize = True
        Me.lbl46.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.lbl46.Location = New System.Drawing.Point(531, 435)
        Me.lbl46.Name = "lbl46"
        Me.lbl46.Size = New System.Drawing.Size(20, 17)
        Me.lbl46.TabIndex = 46
        Me.lbl46.Text = "   "
        '
        'lbl45
        '
        Me.lbl45.AutoSize = True
        Me.lbl45.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl45.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl45.Location = New System.Drawing.Point(401, 435)
        Me.lbl45.Name = "lbl45"
        Me.lbl45.Size = New System.Drawing.Size(20, 17)
        Me.lbl45.TabIndex = 45
        Me.lbl45.Text = "   "
        '
        'lbl44
        '
        Me.lbl44.AutoSize = True
        Me.lbl44.BackColor = System.Drawing.Color.Yellow
        Me.lbl44.Location = New System.Drawing.Point(305, 422)
        Me.lbl44.Name = "lbl44"
        Me.lbl44.Size = New System.Drawing.Size(20, 17)
        Me.lbl44.TabIndex = 44
        Me.lbl44.Text = "   "
        '
        'lbl43
        '
        Me.lbl43.AutoSize = True
        Me.lbl43.BackColor = System.Drawing.Color.LightGreen
        Me.lbl43.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.lbl43.ForeColor = System.Drawing.Color.LightGreen
        Me.lbl43.Location = New System.Drawing.Point(209, 411)
        Me.lbl43.Name = "lbl43"
        Me.lbl43.Size = New System.Drawing.Size(20, 17)
        Me.lbl43.TabIndex = 43
        Me.lbl43.Text = "   "
        '
        'lbl42
        '
        Me.lbl42.AutoSize = True
        Me.lbl42.BackColor = System.Drawing.Color.Transparent
        Me.lbl42.Location = New System.Drawing.Point(152, 446)
        Me.lbl42.Name = "lbl42"
        Me.lbl42.Size = New System.Drawing.Size(20, 17)
        Me.lbl42.TabIndex = 42
        Me.lbl42.Text = "   "
        '
        'lbl41
        '
        Me.lbl41.AutoSize = True
        Me.lbl41.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.lbl41.Location = New System.Drawing.Point(12, 396)
        Me.lbl41.Name = "lbl41"
        Me.lbl41.Size = New System.Drawing.Size(20, 17)
        Me.lbl41.TabIndex = 41
        Me.lbl41.Text = "   "
        '
        'lbl40
        '
        Me.lbl40.AutoSize = True
        Me.lbl40.BackColor = System.Drawing.Color.Transparent
        Me.lbl40.Location = New System.Drawing.Point(868, 502)
        Me.lbl40.Name = "lbl40"
        Me.lbl40.Size = New System.Drawing.Size(20, 17)
        Me.lbl40.TabIndex = 40
        Me.lbl40.Text = "   "
        '
        'lbl39
        '
        Me.lbl39.AutoSize = True
        Me.lbl39.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.lbl39.Location = New System.Drawing.Point(806, 526)
        Me.lbl39.Name = "lbl39"
        Me.lbl39.Size = New System.Drawing.Size(20, 17)
        Me.lbl39.TabIndex = 39
        Me.lbl39.Text = "   "
        '
        'lbl38
        '
        Me.lbl38.AutoSize = True
        Me.lbl38.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl38.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl38.Location = New System.Drawing.Point(708, 526)
        Me.lbl38.Name = "lbl38"
        Me.lbl38.Size = New System.Drawing.Size(20, 17)
        Me.lbl38.TabIndex = 38
        Me.lbl38.Text = "   "
        '
        'lbl37
        '
        Me.lbl37.AutoSize = True
        Me.lbl37.BackColor = System.Drawing.Color.Yellow
        Me.lbl37.Location = New System.Drawing.Point(577, 526)
        Me.lbl37.Name = "lbl37"
        Me.lbl37.Size = New System.Drawing.Size(20, 17)
        Me.lbl37.TabIndex = 37
        Me.lbl37.Text = "   "
        '
        'lbl36
        '
        Me.lbl36.AutoSize = True
        Me.lbl36.BackColor = System.Drawing.Color.LightGreen
        Me.lbl36.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.lbl36.ForeColor = System.Drawing.Color.LightGreen
        Me.lbl36.Location = New System.Drawing.Point(483, 478)
        Me.lbl36.Name = "lbl36"
        Me.lbl36.Size = New System.Drawing.Size(20, 17)
        Me.lbl36.TabIndex = 36
        Me.lbl36.Text = "   "
        '
        'lbl35
        '
        Me.lbl35.AutoSize = True
        Me.lbl35.BackColor = System.Drawing.Color.Transparent
        Me.lbl35.Location = New System.Drawing.Point(401, 512)
        Me.lbl35.Name = "lbl35"
        Me.lbl35.Size = New System.Drawing.Size(20, 17)
        Me.lbl35.TabIndex = 35
        Me.lbl35.Text = "   "
        '
        'lbl34
        '
        Me.lbl34.AutoSize = True
        Me.lbl34.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.lbl34.Location = New System.Drawing.Point(344, 526)
        Me.lbl34.Name = "lbl34"
        Me.lbl34.Size = New System.Drawing.Size(20, 17)
        Me.lbl34.TabIndex = 34
        Me.lbl34.Text = "   "
        '
        'lbl33
        '
        Me.lbl33.AutoSize = True
        Me.lbl33.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl33.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl33.Location = New System.Drawing.Point(221, 512)
        Me.lbl33.Name = "lbl33"
        Me.lbl33.Size = New System.Drawing.Size(20, 17)
        Me.lbl33.TabIndex = 33
        Me.lbl33.Text = "   "
        '
        'lbl32
        '
        Me.lbl32.AutoSize = True
        Me.lbl32.BackColor = System.Drawing.Color.Yellow
        Me.lbl32.Location = New System.Drawing.Point(115, 489)
        Me.lbl32.Name = "lbl32"
        Me.lbl32.Size = New System.Drawing.Size(20, 17)
        Me.lbl32.TabIndex = 32
        Me.lbl32.Text = "   "
        '
        'lbl31
        '
        Me.lbl31.AutoSize = True
        Me.lbl31.BackColor = System.Drawing.Color.LightGreen
        Me.lbl31.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.lbl31.ForeColor = System.Drawing.Color.LightGreen
        Me.lbl31.Location = New System.Drawing.Point(34, 512)
        Me.lbl31.Name = "lbl31"
        Me.lbl31.Size = New System.Drawing.Size(20, 17)
        Me.lbl31.TabIndex = 31
        Me.lbl31.Text = "   "
        '
        'lbl30
        '
        Me.lbl30.AutoSize = True
        Me.lbl30.BackColor = System.Drawing.Color.Yellow
        Me.lbl30.Location = New System.Drawing.Point(877, 588)
        Me.lbl30.Name = "lbl30"
        Me.lbl30.Size = New System.Drawing.Size(20, 17)
        Me.lbl30.TabIndex = 30
        Me.lbl30.Text = "   "
        '
        'lbl29
        '
        Me.lbl29.AutoSize = True
        Me.lbl29.BackColor = System.Drawing.Color.LightGreen
        Me.lbl29.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.lbl29.ForeColor = System.Drawing.Color.LightGreen
        Me.lbl29.Location = New System.Drawing.Point(806, 588)
        Me.lbl29.Name = "lbl29"
        Me.lbl29.Size = New System.Drawing.Size(20, 17)
        Me.lbl29.TabIndex = 29
        Me.lbl29.Text = "   "
        '
        'lbl28
        '
        Me.lbl28.AutoSize = True
        Me.lbl28.BackColor = System.Drawing.Color.Transparent
        Me.lbl28.Location = New System.Drawing.Point(683, 588)
        Me.lbl28.Name = "lbl28"
        Me.lbl28.Size = New System.Drawing.Size(20, 17)
        Me.lbl28.TabIndex = 28
        Me.lbl28.Text = "   "
        '
        'lbl27
        '
        Me.lbl27.AutoSize = True
        Me.lbl27.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.lbl27.Location = New System.Drawing.Point(588, 560)
        Me.lbl27.Name = "lbl27"
        Me.lbl27.Size = New System.Drawing.Size(20, 17)
        Me.lbl27.TabIndex = 27
        Me.lbl27.Text = "   "
        '
        'lbl26
        '
        Me.lbl26.AutoSize = True
        Me.lbl26.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl26.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl26.Location = New System.Drawing.Point(486, 579)
        Me.lbl26.Name = "lbl26"
        Me.lbl26.Size = New System.Drawing.Size(20, 17)
        Me.lbl26.TabIndex = 26
        Me.lbl26.Text = "   "
        '
        'lbl25
        '
        Me.lbl25.AutoSize = True
        Me.lbl25.BackColor = System.Drawing.Color.Yellow
        Me.lbl25.Location = New System.Drawing.Point(386, 560)
        Me.lbl25.Name = "lbl25"
        Me.lbl25.Size = New System.Drawing.Size(20, 17)
        Me.lbl25.TabIndex = 25
        Me.lbl25.Text = "   "
        '
        'lbl24
        '
        Me.lbl24.AutoSize = True
        Me.lbl24.BackColor = System.Drawing.Color.LightGreen
        Me.lbl24.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.lbl24.ForeColor = System.Drawing.Color.LightGreen
        Me.lbl24.Location = New System.Drawing.Point(334, 588)
        Me.lbl24.Name = "lbl24"
        Me.lbl24.Size = New System.Drawing.Size(20, 17)
        Me.lbl24.TabIndex = 24
        Me.lbl24.Text = "   "
        '
        'lbl23
        '
        Me.lbl23.AutoSize = True
        Me.lbl23.BackColor = System.Drawing.Color.Transparent
        Me.lbl23.Location = New System.Drawing.Point(221, 607)
        Me.lbl23.Name = "lbl23"
        Me.lbl23.Size = New System.Drawing.Size(20, 17)
        Me.lbl23.TabIndex = 23
        Me.lbl23.Text = "   "
        '
        'lbl22
        '
        Me.lbl22.AutoSize = True
        Me.lbl22.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.lbl22.Location = New System.Drawing.Point(152, 579)
        Me.lbl22.Name = "lbl22"
        Me.lbl22.Size = New System.Drawing.Size(20, 17)
        Me.lbl22.TabIndex = 22
        Me.lbl22.Text = "   "
        '
        'lbl21
        '
        Me.lbl21.AutoSize = True
        Me.lbl21.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl21.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl21.Location = New System.Drawing.Point(52, 598)
        Me.lbl21.Name = "lbl21"
        Me.lbl21.Size = New System.Drawing.Size(20, 17)
        Me.lbl21.TabIndex = 21
        Me.lbl21.Text = "   "
        '
        'lbl20
        '
        Me.lbl20.AutoSize = True
        Me.lbl20.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.lbl20.Location = New System.Drawing.Point(889, 675)
        Me.lbl20.Name = "lbl20"
        Me.lbl20.Size = New System.Drawing.Size(20, 17)
        Me.lbl20.TabIndex = 20
        Me.lbl20.Text = "   "
        '
        'lbl19
        '
        Me.lbl19.AutoSize = True
        Me.lbl19.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl19.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl19.Location = New System.Drawing.Point(806, 675)
        Me.lbl19.Name = "lbl19"
        Me.lbl19.Size = New System.Drawing.Size(20, 17)
        Me.lbl19.TabIndex = 19
        Me.lbl19.Text = "   "
        '
        'lbl18
        '
        Me.lbl18.AutoSize = True
        Me.lbl18.BackColor = System.Drawing.Color.Yellow
        Me.lbl18.Location = New System.Drawing.Point(668, 655)
        Me.lbl18.Name = "lbl18"
        Me.lbl18.Size = New System.Drawing.Size(20, 17)
        Me.lbl18.TabIndex = 18
        Me.lbl18.Text = "   "
        '
        'lbl16
        '
        Me.lbl16.AutoSize = True
        Me.lbl16.BackColor = System.Drawing.Color.Transparent
        Me.lbl16.Location = New System.Drawing.Point(486, 645)
        Me.lbl16.Name = "lbl16"
        Me.lbl16.Size = New System.Drawing.Size(20, 17)
        Me.lbl16.TabIndex = 16
        Me.lbl16.Text = "   "
        '
        'lbl15
        '
        Me.lbl15.AutoSize = True
        Me.lbl15.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.lbl15.Location = New System.Drawing.Point(386, 675)
        Me.lbl15.Name = "lbl15"
        Me.lbl15.Size = New System.Drawing.Size(20, 17)
        Me.lbl15.TabIndex = 15
        Me.lbl15.Text = "   "
        '
        'lbl14
        '
        Me.lbl14.AutoSize = True
        Me.lbl14.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl14.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl14.Location = New System.Drawing.Point(305, 675)
        Me.lbl14.Name = "lbl14"
        Me.lbl14.Size = New System.Drawing.Size(20, 17)
        Me.lbl14.TabIndex = 14
        Me.lbl14.Text = "   "
        '
        'lbl13
        '
        Me.lbl13.AutoSize = True
        Me.lbl13.BackColor = System.Drawing.Color.Yellow
        Me.lbl13.Location = New System.Drawing.Point(252, 675)
        Me.lbl13.Name = "lbl13"
        Me.lbl13.Size = New System.Drawing.Size(20, 17)
        Me.lbl13.TabIndex = 13
        Me.lbl13.Text = "   "
        '
        'lbl12
        '
        Me.lbl12.AutoSize = True
        Me.lbl12.BackColor = System.Drawing.Color.LightGreen
        Me.lbl12.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.lbl12.ForeColor = System.Drawing.Color.LightGreen
        Me.lbl12.Location = New System.Drawing.Point(128, 675)
        Me.lbl12.Name = "lbl12"
        Me.lbl12.Size = New System.Drawing.Size(20, 17)
        Me.lbl12.TabIndex = 12
        Me.lbl12.Text = "   "
        '
        'lbl11
        '
        Me.lbl11.AutoSize = True
        Me.lbl11.BackColor = System.Drawing.Color.Transparent
        Me.lbl11.Location = New System.Drawing.Point(25, 655)
        Me.lbl11.Name = "lbl11"
        Me.lbl11.Size = New System.Drawing.Size(20, 17)
        Me.lbl11.TabIndex = 11
        Me.lbl11.Text = "   "
        '
        'lbl10
        '
        Me.lbl10.AutoSize = True
        Me.lbl10.BackColor = System.Drawing.Color.LightGreen
        Me.lbl10.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.lbl10.ForeColor = System.Drawing.Color.LightGreen
        Me.lbl10.Location = New System.Drawing.Point(865, 721)
        Me.lbl10.Name = "lbl10"
        Me.lbl10.Size = New System.Drawing.Size(20, 17)
        Me.lbl10.TabIndex = 10
        Me.lbl10.Text = "   "
        '
        'lbl9
        '
        Me.lbl9.AutoSize = True
        Me.lbl9.BackColor = System.Drawing.Color.Transparent
        Me.lbl9.Location = New System.Drawing.Point(764, 721)
        Me.lbl9.Name = "lbl9"
        Me.lbl9.Size = New System.Drawing.Size(20, 17)
        Me.lbl9.TabIndex = 9
        Me.lbl9.Text = "   "
        '
        'lbl8
        '
        Me.lbl8.AutoSize = True
        Me.lbl8.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.lbl8.Location = New System.Drawing.Point(683, 734)
        Me.lbl8.Name = "lbl8"
        Me.lbl8.Size = New System.Drawing.Size(20, 17)
        Me.lbl8.TabIndex = 8
        Me.lbl8.Text = "   "
        '
        'lbl7
        '
        Me.lbl7.AutoSize = True
        Me.lbl7.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl7.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl7.Location = New System.Drawing.Point(598, 734)
        Me.lbl7.Name = "lbl7"
        Me.lbl7.Size = New System.Drawing.Size(20, 17)
        Me.lbl7.TabIndex = 7
        Me.lbl7.Text = "   "
        '
        'lbl6
        '
        Me.lbl6.AutoSize = True
        Me.lbl6.BackColor = System.Drawing.Color.Yellow
        Me.lbl6.Location = New System.Drawing.Point(499, 748)
        Me.lbl6.Name = "lbl6"
        Me.lbl6.Size = New System.Drawing.Size(20, 17)
        Me.lbl6.TabIndex = 6
        Me.lbl6.Text = "   "
        '
        'lbl5
        '
        Me.lbl5.AutoSize = True
        Me.lbl5.BackColor = System.Drawing.Color.LightGreen
        Me.lbl5.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.lbl5.ForeColor = System.Drawing.Color.LightGreen
        Me.lbl5.Location = New System.Drawing.Point(425, 748)
        Me.lbl5.Name = "lbl5"
        Me.lbl5.Size = New System.Drawing.Size(20, 17)
        Me.lbl5.TabIndex = 5
        Me.lbl5.Text = "   "
        '
        'lbl4
        '
        Me.lbl4.AutoSize = True
        Me.lbl4.BackColor = System.Drawing.Color.Transparent
        Me.lbl4.Location = New System.Drawing.Point(317, 734)
        Me.lbl4.Name = "lbl4"
        Me.lbl4.Size = New System.Drawing.Size(20, 17)
        Me.lbl4.TabIndex = 4
        Me.lbl4.Text = "   "
        '
        'lbl3
        '
        Me.lbl3.AutoSize = True
        Me.lbl3.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.lbl3.Location = New System.Drawing.Point(221, 748)
        Me.lbl3.Name = "lbl3"
        Me.lbl3.Size = New System.Drawing.Size(20, 17)
        Me.lbl3.TabIndex = 3
        Me.lbl3.Text = "   "
        '
        'lbl2
        '
        Me.lbl2.AutoSize = True
        Me.lbl2.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl2.Location = New System.Drawing.Point(128, 748)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(20, 17)
        Me.lbl2.TabIndex = 2
        Me.lbl2.Text = "   "
        '
        'lbl1
        '
        Me.lbl1.AutoSize = True
        Me.lbl1.BackColor = System.Drawing.Color.Yellow
        Me.lbl1.Location = New System.Drawing.Point(64, 760)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(20, 17)
        Me.lbl1.TabIndex = 1
        Me.lbl1.Text = "   "
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Georgia", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(964, 21)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(106, 17)
        Me.Label1.TabIndex = 109
        Me.Label1.Text = "CURR_TURN"
        '
        'Timer1
        '
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(967, 429)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(208, 23)
        Me.ProgressBar1.TabIndex = 111
        '
        'Form1
        '
        Me.AcceptButton = Me.btnrotate
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1208, 794)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblblue)
        Me.Controls.Add(Me.lblred)
        Me.Controls.Add(Me.lblplayer2)
        Me.Controls.Add(Me.pctDice)
        Me.Controls.Add(Me.btnrotate)
        Me.Controls.Add(Me.lblplayer1)
        Me.Controls.Add(Me.lbl100)
        Me.Controls.Add(Me.lbl99)
        Me.Controls.Add(Me.lbl98)
        Me.Controls.Add(Me.lbl97)
        Me.Controls.Add(Me.lbl96)
        Me.Controls.Add(Me.lbl95)
        Me.Controls.Add(Me.lbl94)
        Me.Controls.Add(Me.lbl93)
        Me.Controls.Add(Me.lbl92)
        Me.Controls.Add(Me.lbl91)
        Me.Controls.Add(Me.lbl90)
        Me.Controls.Add(Me.lbl89)
        Me.Controls.Add(Me.lbl88)
        Me.Controls.Add(Me.lbl87)
        Me.Controls.Add(Me.lbl86)
        Me.Controls.Add(Me.lbl85)
        Me.Controls.Add(Me.lbl84)
        Me.Controls.Add(Me.lbl83)
        Me.Controls.Add(Me.lbl82)
        Me.Controls.Add(Me.lbl81)
        Me.Controls.Add(Me.lbl80)
        Me.Controls.Add(Me.lbl79)
        Me.Controls.Add(Me.lbl78)
        Me.Controls.Add(Me.lbl77)
        Me.Controls.Add(Me.lbl76)
        Me.Controls.Add(Me.lbl75)
        Me.Controls.Add(Me.lbl74)
        Me.Controls.Add(Me.lbl73)
        Me.Controls.Add(Me.lbl72)
        Me.Controls.Add(Me.lbl71)
        Me.Controls.Add(Me.lbl70)
        Me.Controls.Add(Me.lbl69)
        Me.Controls.Add(Me.lbl68)
        Me.Controls.Add(Me.lbl67)
        Me.Controls.Add(Me.lbl66)
        Me.Controls.Add(Me.lbl65)
        Me.Controls.Add(Me.lbl64)
        Me.Controls.Add(Me.lbl63)
        Me.Controls.Add(Me.lbl62)
        Me.Controls.Add(Me.lbl61)
        Me.Controls.Add(Me.lbl60)
        Me.Controls.Add(Me.lbl59)
        Me.Controls.Add(Me.lbl58)
        Me.Controls.Add(Me.lbl57)
        Me.Controls.Add(Me.lbl56)
        Me.Controls.Add(Me.lbl55)
        Me.Controls.Add(Me.lbl54)
        Me.Controls.Add(Me.lbl53)
        Me.Controls.Add(Me.lbl52)
        Me.Controls.Add(Me.lbl51)
        Me.Controls.Add(Me.lbl50)
        Me.Controls.Add(Me.lbl49)
        Me.Controls.Add(Me.lbl48)
        Me.Controls.Add(Me.lbl47)
        Me.Controls.Add(Me.lbl46)
        Me.Controls.Add(Me.lbl45)
        Me.Controls.Add(Me.lbl44)
        Me.Controls.Add(Me.lbl43)
        Me.Controls.Add(Me.lbl42)
        Me.Controls.Add(Me.lbl41)
        Me.Controls.Add(Me.lbl40)
        Me.Controls.Add(Me.lbl39)
        Me.Controls.Add(Me.lbl38)
        Me.Controls.Add(Me.lbl37)
        Me.Controls.Add(Me.lbl36)
        Me.Controls.Add(Me.lbl35)
        Me.Controls.Add(Me.lbl34)
        Me.Controls.Add(Me.lbl33)
        Me.Controls.Add(Me.lbl32)
        Me.Controls.Add(Me.lbl31)
        Me.Controls.Add(Me.lbl30)
        Me.Controls.Add(Me.lbl29)
        Me.Controls.Add(Me.lbl28)
        Me.Controls.Add(Me.lbl27)
        Me.Controls.Add(Me.lbl26)
        Me.Controls.Add(Me.lbl25)
        Me.Controls.Add(Me.lbl24)
        Me.Controls.Add(Me.lbl23)
        Me.Controls.Add(Me.lbl22)
        Me.Controls.Add(Me.lbl21)
        Me.Controls.Add(Me.lbl20)
        Me.Controls.Add(Me.lbl19)
        Me.Controls.Add(Me.lbl18)
        Me.Controls.Add(Me.lbl17)
        Me.Controls.Add(Me.lbl16)
        Me.Controls.Add(Me.lbl15)
        Me.Controls.Add(Me.lbl14)
        Me.Controls.Add(Me.lbl13)
        Me.Controls.Add(Me.lbl12)
        Me.Controls.Add(Me.lbl11)
        Me.Controls.Add(Me.lbl10)
        Me.Controls.Add(Me.lbl9)
        Me.Controls.Add(Me.lbl8)
        Me.Controls.Add(Me.lbl7)
        Me.Controls.Add(Me.lbl6)
        Me.Controls.Add(Me.lbl5)
        Me.Controls.Add(Me.lbl4)
        Me.Controls.Add(Me.lbl3)
        Me.Controls.Add(Me.lbl2)
        Me.Controls.Add(Me.lbl1)
        Me.Controls.Add(Me.PictureBox1)
        Me.IsMdiContainer = True
        Me.Name = "Form1"
        Me.Text = " "
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pctDice, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents lblblue As System.Windows.Forms.Label
    Friend WithEvents lblred As System.Windows.Forms.Label
    Friend WithEvents lblplayer2 As System.Windows.Forms.Label
    Friend WithEvents btnrotate As System.Windows.Forms.Button
    Friend WithEvents lbl17 As System.Windows.Forms.Label
    Friend WithEvents lblplayer1 As System.Windows.Forms.Label
    Friend WithEvents lbl100 As System.Windows.Forms.Label
    Friend WithEvents lbl99 As System.Windows.Forms.Label
    Friend WithEvents lbl98 As System.Windows.Forms.Label
    Friend WithEvents lbl97 As System.Windows.Forms.Label
    Friend WithEvents lbl96 As System.Windows.Forms.Label
    Friend WithEvents lbl95 As System.Windows.Forms.Label
    Friend WithEvents lbl94 As System.Windows.Forms.Label
    Friend WithEvents lbl93 As System.Windows.Forms.Label
    Friend WithEvents lbl92 As System.Windows.Forms.Label
    Friend WithEvents lbl91 As System.Windows.Forms.Label
    Friend WithEvents lbl90 As System.Windows.Forms.Label
    Friend WithEvents lbl89 As System.Windows.Forms.Label
    Friend WithEvents lbl88 As System.Windows.Forms.Label
    Friend WithEvents lbl87 As System.Windows.Forms.Label
    Friend WithEvents lbl86 As System.Windows.Forms.Label
    Friend WithEvents lbl85 As System.Windows.Forms.Label
    Friend WithEvents lbl84 As System.Windows.Forms.Label
    Friend WithEvents lbl83 As System.Windows.Forms.Label
    Friend WithEvents lbl82 As System.Windows.Forms.Label
    Friend WithEvents lbl81 As System.Windows.Forms.Label
    Friend WithEvents lbl80 As System.Windows.Forms.Label
    Friend WithEvents lbl79 As System.Windows.Forms.Label
    Friend WithEvents lbl78 As System.Windows.Forms.Label
    Friend WithEvents lbl77 As System.Windows.Forms.Label
    Friend WithEvents lbl76 As System.Windows.Forms.Label
    Friend WithEvents lbl75 As System.Windows.Forms.Label
    Friend WithEvents lbl74 As System.Windows.Forms.Label
    Friend WithEvents lbl73 As System.Windows.Forms.Label
    Friend WithEvents lbl72 As System.Windows.Forms.Label
    Friend WithEvents lbl71 As System.Windows.Forms.Label
    Friend WithEvents lbl70 As System.Windows.Forms.Label
    Friend WithEvents lbl69 As System.Windows.Forms.Label
    Friend WithEvents lbl68 As System.Windows.Forms.Label
    Friend WithEvents lbl67 As System.Windows.Forms.Label
    Friend WithEvents lbl66 As System.Windows.Forms.Label
    Friend WithEvents lbl65 As System.Windows.Forms.Label
    Friend WithEvents lbl64 As System.Windows.Forms.Label
    Friend WithEvents lbl63 As System.Windows.Forms.Label
    Friend WithEvents lbl62 As System.Windows.Forms.Label
    Friend WithEvents lbl61 As System.Windows.Forms.Label
    Friend WithEvents lbl60 As System.Windows.Forms.Label
    Friend WithEvents lbl59 As System.Windows.Forms.Label
    Friend WithEvents lbl58 As System.Windows.Forms.Label
    Friend WithEvents lbl57 As System.Windows.Forms.Label
    Friend WithEvents lbl56 As System.Windows.Forms.Label
    Friend WithEvents lbl55 As System.Windows.Forms.Label
    Friend WithEvents lbl54 As System.Windows.Forms.Label
    Friend WithEvents lbl53 As System.Windows.Forms.Label
    Friend WithEvents lbl52 As System.Windows.Forms.Label
    Friend WithEvents lbl51 As System.Windows.Forms.Label
    Friend WithEvents lbl50 As System.Windows.Forms.Label
    Friend WithEvents lbl49 As System.Windows.Forms.Label
    Friend WithEvents lbl48 As System.Windows.Forms.Label
    Friend WithEvents lbl47 As System.Windows.Forms.Label
    Friend WithEvents lbl46 As System.Windows.Forms.Label
    Friend WithEvents lbl45 As System.Windows.Forms.Label
    Friend WithEvents lbl44 As System.Windows.Forms.Label
    Friend WithEvents lbl43 As System.Windows.Forms.Label
    Friend WithEvents lbl42 As System.Windows.Forms.Label
    Friend WithEvents lbl41 As System.Windows.Forms.Label
    Friend WithEvents lbl40 As System.Windows.Forms.Label
    Friend WithEvents lbl39 As System.Windows.Forms.Label
    Friend WithEvents lbl38 As System.Windows.Forms.Label
    Friend WithEvents lbl37 As System.Windows.Forms.Label
    Friend WithEvents lbl36 As System.Windows.Forms.Label
    Friend WithEvents lbl35 As System.Windows.Forms.Label
    Friend WithEvents lbl34 As System.Windows.Forms.Label
    Friend WithEvents lbl33 As System.Windows.Forms.Label
    Friend WithEvents lbl32 As System.Windows.Forms.Label
    Friend WithEvents lbl31 As System.Windows.Forms.Label
    Friend WithEvents lbl30 As System.Windows.Forms.Label
    Friend WithEvents lbl29 As System.Windows.Forms.Label
    Friend WithEvents lbl28 As System.Windows.Forms.Label
    Friend WithEvents lbl27 As System.Windows.Forms.Label
    Friend WithEvents lbl26 As System.Windows.Forms.Label
    Friend WithEvents lbl25 As System.Windows.Forms.Label
    Friend WithEvents lbl24 As System.Windows.Forms.Label
    Friend WithEvents lbl23 As System.Windows.Forms.Label
    Friend WithEvents lbl22 As System.Windows.Forms.Label
    Friend WithEvents lbl21 As System.Windows.Forms.Label
    Friend WithEvents lbl20 As System.Windows.Forms.Label
    Friend WithEvents lbl19 As System.Windows.Forms.Label
    Friend WithEvents lbl18 As System.Windows.Forms.Label
    Friend WithEvents lbl16 As System.Windows.Forms.Label
    Friend WithEvents lbl15 As System.Windows.Forms.Label
    Friend WithEvents lbl14 As System.Windows.Forms.Label
    Friend WithEvents lbl13 As System.Windows.Forms.Label
    Friend WithEvents lbl12 As System.Windows.Forms.Label
    Friend WithEvents lbl11 As System.Windows.Forms.Label
    Friend WithEvents lbl10 As System.Windows.Forms.Label
    Friend WithEvents lbl9 As System.Windows.Forms.Label
    Friend WithEvents lbl8 As System.Windows.Forms.Label
    Friend WithEvents lbl7 As System.Windows.Forms.Label
    Friend WithEvents lbl6 As System.Windows.Forms.Label
    Friend WithEvents lbl5 As System.Windows.Forms.Label
    Friend WithEvents lbl4 As System.Windows.Forms.Label
    Friend WithEvents lbl3 As System.Windows.Forms.Label
    Friend WithEvents lbl2 As System.Windows.Forms.Label
    Friend WithEvents lbl1 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents pctDice As System.Windows.Forms.PictureBox

End Class
